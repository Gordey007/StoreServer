create function check_dept(dept char(4))
  returns char(20)
  BEGIN 
DECLARE boss_no INT DEFAULT 0;
DECLARE boss_name CHAR(30);

SELECT max(emp_no) into boss_no FROM dept_manager
WHERE dept = dept_no;


 return concat('boss no ', boss_no);

END;

