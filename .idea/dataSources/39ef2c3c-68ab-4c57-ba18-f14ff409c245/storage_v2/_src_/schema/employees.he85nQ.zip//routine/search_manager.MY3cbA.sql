create function search_manager(name char(20), last char(20))
  returns char(50)
  BEGIN 

	DECLARE empno INT DEFAULT 0;
	DECLARE boss CHAR(30);
	DECLARE bossno INT DEFAULT 0;
	DECLARE deptno CHAR(30);

	SELECT max(emp_no) into empno FROM employees where first_name = name AND last_name = last;
	SELECT dept_no into deptno FROM dept_emp WHERE empno = emp_no;
	SELECT max(emp_no) into empno FROM dept_manager WHERE deptno = dept_no;
	SELECT max(emp_no) into bossno FROM employees WHERE empno = emp_no;
	SELECT concat(first_name,' ', last_name) into boss FROM employees WHERE bossno = emp_no;

	return concat('manager:', bossno,' ', boss); 

END;

