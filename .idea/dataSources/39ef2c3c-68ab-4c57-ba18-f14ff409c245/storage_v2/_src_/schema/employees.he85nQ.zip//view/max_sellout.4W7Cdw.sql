create view max_sellout as
  select max(`employees`.`salaries`.`salary`) AS `max(salary)`
  from `employees`.`salaries`;

