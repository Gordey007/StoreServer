create trigger bonus
  before INSERT
  on employ2
  for each row
  BEGIN

	SET NEW.salary = NEW.salary + 5523;

END;

