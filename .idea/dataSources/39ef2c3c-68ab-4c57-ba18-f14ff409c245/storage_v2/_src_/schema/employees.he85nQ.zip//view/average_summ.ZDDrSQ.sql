create view average_summ as
  select
    `employees`.`departments`.`dept_name`                                           AS `dept_name`,
    (sum(`employees`.`salaries`.`salary`) / count(
        `employees`.`dept_emp`.`emp_no`))                                           AS `sum(salaries.salary)/count(dept_emp.emp_no)`
  from ((`employees`.`departments`
    left join `employees`.`dept_emp`
      on ((`employees`.`departments`.`dept_no` = `employees`.`dept_emp`.`dept_no`))) left join `employees`.`salaries`
      on ((`employees`.`dept_emp`.`emp_no` = `employees`.`salaries`.`emp_no`)))
  where (`employees`.`salaries`.`salary` = (select max(`employees`.`salaries`.`salary`)
                                            from `employees`.`salaries`
                                            where (`employees`.`salaries`.`emp_no` = `employees`.`dept_emp`.`emp_no`)))
  group by `employees`.`departments`.`dept_no`;

